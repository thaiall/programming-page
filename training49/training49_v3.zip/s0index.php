<html><head>
<meta http-equiv="content-type" content="text/html;charset=windows-874" />
</head><body><ol><b>Manage data in mysql</b>
<li>s1connect.php</li>
<li><a href="s2crtdb.php">s2crtdb.php</a></li>
<li><a href="s3select.php">s3select.php</a></li>
<li><a href="s4insert.php">s4insert.php</a></li>
<li><a href="s5delete.php">s5delete.php</a></li>
<li><a href="s6update.php">s6update.php</a></li>
<li><a href="s7drop.php">s7drop.php</a></li>
</ol>
<?php 
/* updated for php7 and php 5 on 2560-09-13 */
if(file_exists("s3select.php")) include("s3select.php"); 
?>
</body></html>